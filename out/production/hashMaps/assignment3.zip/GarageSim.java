public class GarageSim{
	public void insert(Integer x){}
	public void treat(){}
	public int times(Integer x){}
}
