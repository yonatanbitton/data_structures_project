public class HTLinearProbing extends OpenAddressingBGU {}
