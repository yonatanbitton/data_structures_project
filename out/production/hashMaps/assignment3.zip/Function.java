public interface Function {
    int h(Object x);
}
